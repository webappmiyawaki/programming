package model;

public class RegisterUserLogic {
  public boolean execute(User user) {
    // 登録処理（サンプルでは登録処理を行わない）
    return true;
  }
}